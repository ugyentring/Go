package main

import (
	routes "myapp/route"
)


func main() {
	routes.InitializeRoutes()
}